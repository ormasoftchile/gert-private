# Gert v2 Design Document

Built: 2026-04-18T15:45:09.359103

Contents:
- main.pdf: Compiled design document
- main.tex: Root LaTeX file
- sections/: Individual design sections
- README.md: Build and usage instructions
